import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hello_me/auth_repository.dart';
import 'package:provider/provider.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.symmetric(horizontal: 24.0),
          children: <Widget>[
            SizedBox(height: 24.0),
            Text('Welcome to Startup Name Generator, please login below',
                style: TextStyle(fontSize: 16.0)),
            SizedBox(height: 48.0),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                labelText: 'Email',
              ),
            ),
            SizedBox(height: 12.0),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(
                labelText: 'Password',
              ),
              obscureText: true,
            ),
            Padding(
                padding: EdgeInsets.only(top: 20),
                child: Column(
                  children: <Widget>[
                    SizedBox(
                        width: double.maxFinite,
                        child: Consumer<AuthRepository>(
                            builder: (context, authRepository, _) {
                          return ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                primary: Theme.of(context).primaryColor,
                                onPrimary: Colors.white,
                                shape: StadiumBorder()),
                            child: Text('Login'),
                            onPressed:
                                authRepository.status == Status.Authenticating
                                    ? null
                                    : _onLoginPressed,
                          );
                        })),
                    SizedBox(
                        width: double.maxFinite,
                        child: Consumer<AuthRepository>(
                            builder: (context, authRepository, _) {
                          return ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  primary: Theme.of(context).accentColor,
                                  onPrimary: Colors.white,
                                  shape: StadiumBorder()),
                              child: Text('New user? Click to sign up'),
                              onPressed: () {
                                showModalBottomSheet(context: context,
                                    builder: (context) => _showSignupModal());
                              });
                        })),
                  ],
                )),
          ],
        ),
      ),
    );
  }

  Widget _showSignupModal() {
    return SizedBox(
      height: 180,
      child: Container(padding: EdgeInsets.symmetric(horizontal: 16.0),child: Column(
        children: [
          Center(child: Padding(padding: EdgeInsets.only(top: 12, bottom: 5), child: Text("Please confirm your password below:", style: Theme.of(context).textTheme.bodyText2,))),
          Divider(),
          TextField(
            controller: _confirmPasswordController,
            decoration: InputDecoration(
              labelText: 'Password',
            ),
            obscureText: true,
          ),
          SizedBox(height: 16),
          Center(child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                  primary:
                  Theme.of(context).accentColor),
              onPressed: () {},
              child: Text("Confirm",
                  style: (Theme.of(context)
                      .textTheme
                      .bodyText1 as TextStyle)
                      .merge(TextStyle(
                      color: Colors.white)))))
        ],
      )),
    );
  }

  void _onLoginPressed() async {
    final bool loggedIn =
        await Provider.of<AuthRepository>(context, listen: false)
            .signIn(_emailController.text, _passwordController.text);
    if (loggedIn) {
      Navigator.of(context).pushNamed('/');
    } else {
      final snackBar = SnackBar(content: Text('Failure'));
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
    }
  }
}

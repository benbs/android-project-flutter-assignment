import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hello_me/auth_repository.dart';

class UserProfile extends StatefulWidget {
  final AuthRepository? authRepository;

  UserProfile({this.authRepository});

  @override
  _UserProfileState createState() =>
      _UserProfileState(authRepository: authRepository);
}

class _UserProfileState extends State<UserProfile> {
  final AuthRepository? authRepository;

  _UserProfileState({this.authRepository});

  @override
  Widget build(BuildContext context) {
    return Container(
        color: Colors.white,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
                padding: EdgeInsets.only(top: 16),
                child: SizedBox(
                  width: 100,
                  child: Container(
                    height: 85,
                    width: 85,
                    decoration: new BoxDecoration(
                      color: Colors.orange,
                      shape: BoxShape.circle,
                    ),
                  ),
                )),
            Expanded(
                flex: 1,
                child: Padding(
                    padding: EdgeInsets.only(top: 25, left: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                            child: Text(authRepository?.user?.email ?? "null",
                                style: Theme.of(context).textTheme.bodyText1)),
                        Expanded(
                            flex: 1,
                            child: Padding(
                                padding: EdgeInsets.only(top: 10),
                                child: Column(
                                    children: [ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            primary:
                                                Theme.of(context).accentColor),
                                        onPressed: () {},
                                        child: Text("Change Avatar",
                                            style: (Theme.of(context)
                                                    .textTheme
                                                    .bodyText1 as TextStyle)
                                                .merge(TextStyle(
                                                    color: Colors.white))))])))
                      ],
                    )))
          ],
        ));
  }
}

class UserProfileBanner extends StatelessWidget {
  final VoidCallback? onTap;
  final bool? isOpen;
  final AuthRepository? authRepository;

  UserProfileBanner({this.onTap, this.isOpen, this.authRepository});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () {
          onTap?.call();
        },
        child: Container(
          color: Theme.of(context).bottomAppBarColor,
          padding: EdgeInsets.symmetric(horizontal: 15),
          child: Row(
            children: [
              Expanded(
                  flex: 1,
                  child: Text('Welcome back, ${authRepository?.user?.email}',
                      style: Theme.of(context).textTheme.bodyText2)),
              Icon((isOpen ?? false) ? Icons.expand_more : Icons.expand_less)
            ],
          ),
        ));
  }
}
